package com.example.thucncph13910_asm_duan.Adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Dao.DAOPhieuMuon;
import com.example.thucncph13910_asm_duan.Dao.DAOSach;
import com.example.thucncph13910_asm_duan.Dao.DAOThanhVien;
import com.example.thucncph13910_asm_duan.Model.PhieuMuon;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;
import com.example.thucncph13910_asm_duan.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AdapterPhieuMuon extends RecyclerView.Adapter<ViewHolderPhieuMuon> {
    Context context;
    ArrayList<PhieuMuon> listPM;
    DAOPhieuMuon daoPhieuMuon;
    DAOThanhVien daoThanhVien;
    DAOSach daoSach;
    ThanhVien thanhVien;
    Sach sach;
    int tienThue;
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    ArrayList<ThanhVien> listTV = new ArrayList<>();
    ArrayList<Sach> listS = new ArrayList<>();

    public AdapterPhieuMuon(Context context, ArrayList<PhieuMuon> listPM) {
        this.context = context;
        this.listPM = listPM;
        daoPhieuMuon = new DAOPhieuMuon(context);
        daoThanhVien = new DAOThanhVien(context);
        daoSach = new DAOSach(context);
    }

    @Override
    public ViewHolderPhieuMuon onCreateViewHolder(ViewGroup parent, int viewType) {
        View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_phieumuon, null);
        return new ViewHolderPhieuMuon(view1);
    }

    @Override
    public void onBindViewHolder(ViewHolderPhieuMuon holder, int position) {
        PhieuMuon phieuMuon = listPM.get(position);
        holder.tv_mapm.setText("Mã phiếu: " + phieuMuon.getMaPM());

        thanhVien = daoThanhVien.getID(phieuMuon.getMaTV());
        holder.tv_tentv.setText("Thành viên: " + thanhVien.getHoTen());

        sach = daoSach.getID(String.valueOf(phieuMuon.getMaSach()));
        holder.tv_tensach.setText("Tên sách: " + sach.getTenSach());
        holder.tv_tienthue.setText("Tiền thuê: " + phieuMuon.getTienThue()+"đ");
        holder.tv_ngaythue.setText("Ngày thuê: " + phieuMuon.getNgaytra());
        if (phieuMuon.getTraSach() == 1) {
            holder.tv_trasach.setTextColor(Color.BLUE);
            holder.tv_trasach.setText("Đã trả sách");
        } else {
            holder.tv_trasach.setTextColor(Color.RED);
            holder.tv_trasach.setText("Chưa trả sách");
        }
        holder.img_deletePM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete, null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_closee = view1.findViewById(R.id.btn_closee);
                ImageView img_closee = view1.findViewById(R.id.img_closee);
                img_closee.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btn_closee.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        long kq = daoPhieuMuon.deletePM(phieuMuon.getMaPM());
                        if (kq > 0) {
                            listPM.clear();
                            listPM.addAll(daoPhieuMuon.getAllPM());
                            notifyDataSetChanged();
                            Toast.makeText(view1.getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        } else {
                            Toast.makeText(view1.getContext(), "Xóa thất bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }
                    }
                });
            }
        });
        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.dialog_updatephieumuon, null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_updatePM = view1.findViewById(R.id.btn_updatePM);
                Button btn_closeeUPM = view1.findViewById(R.id.btn_closeeUPM);
                EditText txt_updatengaytra = view1.findViewById(R.id.txt_updatengaytra);
                EditText txt_updatetienthue = view1.findViewById(R.id.txt_updatetienthue);
                Spinner spn_updatematv = view1.findViewById(R.id.spn_updatematv);
                Spinner spn_updatemasach = view1.findViewById(R.id.spn_updatemasach);
                CheckBox chk_updatetrasach = view1.findViewById(R.id.chk_updatetrasach);
                txt_updatengaytra.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, month);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                txt_updatengaytra.setText(dateFormat.format(calendar.getTime()));
                            }
                        };
                        DatePickerDialog pickerDialog = new DatePickerDialog(view.getContext(), callback, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                        pickerDialog.show();
                    }
                });
                //load data lên dialog
                btn_closeeUPM.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                txt_updatengaytra.setText(phieuMuon.getNgaytra());
//                sach = daoSach.getID(String.valueOf(phieuMuon.getMaSach()));
                txt_updatetienthue.setText(String.valueOf(phieuMuon.getTienThue()));
                txt_updatetienthue.setEnabled(false);

                listTV = daoThanhVien.getAllTV();
                ArrayAdapter adapter = new ArrayAdapter(view.getContext(), android.R.layout.simple_list_item_1,listTV);
                spn_updatematv.setAdapter(adapter);
                listS = daoSach.getAllSach();
                ArrayAdapter adapter1 = new ArrayAdapter(view.getContext(), android.R.layout.simple_list_item_1,listS);
                spn_updatemasach.setAdapter(adapter1);
                int positionS = -1;
                for (int i = 0; i < listS.size(); i++) {
                    if ((listS.get(i).getMaSach()) == phieuMuon.getMaSach()) {
                        positionS = i;
                        break;
                    }
                }
                spn_updatemasach.setSelection(positionS);
                int positionTV = -1;
                for (int i = 0; i < listTV.size(); i++) {
                    if ((listTV.get(i).getMaTV()) == phieuMuon.getMaTV()) {
                        positionTV = i;
                        break;
                    }
                }
                spn_updatematv.setSelection(positionTV);
                spn_updatemasach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        tienThue = listS.get(position).getGiaThue();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                if (phieuMuon.getTraSach() == 1) {
                    chk_updatetrasach.setChecked(true);
                } else {
                    chk_updatetrasach.setChecked(false);
                }
                btn_updatePM.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Sach sach = (Sach) spn_updatemasach.getSelectedItem();
                        phieuMuon.setMaSach(sach.getMaSach());
                        ThanhVien thanhVien = (ThanhVien) spn_updatematv.getSelectedItem();
                        phieuMuon.setMaTV(thanhVien.getMaTV());

                        phieuMuon.setTienThue(tienThue);
                        //
                        phieuMuon.setNgaytra(txt_updatengaytra.getText().toString());
                        if (chk_updatetrasach.isChecked()) {
                            phieuMuon.setTraSach(1);
                        } else {
                            phieuMuon.setTraSach(0);
                        }
                        long kq = daoPhieuMuon.updatePM(phieuMuon);
                        if (kq > 0) {
                            listPM.clear();
                            listPM.addAll(daoPhieuMuon.getAllPM());
                            notifyDataSetChanged();
                            Toast.makeText(view1.getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        } else {
                            Toast.makeText(view1.getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }
                    }
                });
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return listPM.size();
    }
}
