package com.example.thucncph13910_asm_duan.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;

import java.util.ArrayList;

public class DAOThanhVien {
    CreateDatabase createDatabase;

    public DAOThanhVien(Context context) {
        createDatabase = new CreateDatabase(context);
    }
    public long insertTV(ThanhVien thanhVien){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ThanhVien.TABLE_HOTEN,thanhVien.getHoTen());
        values.put(ThanhVien.TABLE_NAMSINH,thanhVien.getNamSinh());
        long kq = database.insert(ThanhVien.TABLE_NAME_TV,null,values);
        return kq;
    }
    public int updateTV(ThanhVien thanhVien){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ThanhVien.TABLE_HOTEN,thanhVien.getHoTen());
        values.put(ThanhVien.TABLE_NAMSINH,thanhVien.getNamSinh());
        int kq = database.update(ThanhVien.TABLE_NAME_TV,values,"matv =? " ,new String[]{String.valueOf(thanhVien.getMaTV())});
        return kq;
    }
    public int deleteTV(int ma){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        int kq = database.delete(ThanhVien.TABLE_NAME_TV,"matv =? ",new String[]{String.valueOf(ma)});
        return kq;
    }

    public ArrayList<ThanhVien> getAllDK(String sql , String... a){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<ThanhVien> listTV = new ArrayList<>();
        Cursor cursor = database.rawQuery(sql,a);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int matv = cursor.getInt(0);
            String ten = cursor.getString(1);
            String namsinh = cursor.getString(2);
            ThanhVien thanhVien = new ThanhVien(matv,ten,namsinh);
            listTV.add(thanhVien);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listTV;
    }
    public ArrayList<ThanhVien> getAllTV(){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<ThanhVien> listTV = new ArrayList<>();

        Cursor cursor = database.query(ThanhVien.TABLE_NAME_TV,null,null,null,null,null,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int matv = cursor.getInt(0);
            String ten = cursor.getString(1);
            String namsinh = cursor.getString(2);
            ThanhVien thanhVien = new ThanhVien(matv,ten,namsinh);
            listTV.add(thanhVien);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listTV;
    }
    public ThanhVien getID(int id){
        String select = "SELECT * FROM thanhvien WHERE matv =? ";
        ArrayList<ThanhVien> listTV = getAllDK(select, String.valueOf(id));
        return listTV.get(0);
    }
    public ArrayList<ThanhVien> getIDTV(int id){
        String sele = "SELECT * FROM thanhvien as tv INNER JOIN phieumuon as pm ON tv.matv = pm.matv WHERE tv.matv =? ";
        ArrayList<ThanhVien> list = getAllDK(sele, String.valueOf(id));
        return list;
    }
}
