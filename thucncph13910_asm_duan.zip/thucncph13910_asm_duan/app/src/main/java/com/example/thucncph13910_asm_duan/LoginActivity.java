package com.example.thucncph13910_asm_duan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.example.thucncph13910_asm_duan.Dao.DAOThuThu;
import com.example.thucncph13910_asm_duan.Model.ThuThu;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    Button btn_login, btn_huy;
    TextInputEditText txt_user, txt_pass;
    CheckBox chk_luuThongTin;
    SharedPreferences preferences;
    DAOThuThu daoThuThu;
    String strUser,strPass;
    ArrayList<ThuThu> listTT = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        addControl();
        addEvent();
    }

    private void addEvent() {
        preferences = getSharedPreferences("rememberLogin", MODE_PRIVATE);
        //lấy giá trị từ preferences
        txt_user.setText(preferences.getString("user", ""));
        txt_pass.setText(preferences.getString("pass", ""));
        chk_luuThongTin.setChecked(preferences.getBoolean("checked", false));

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkLogin();
            }
        });
        btn_huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_pass.setText("");
                txt_user.setText("");
            }
        });
    }

    private void checkLogin() {
        strUser = txt_user.getText().toString();
        strPass = txt_pass.getText().toString();
        if (strUser.isEmpty() || strPass.isEmpty()){
            Toast.makeText(this, "Tên đăng nhập và mật khẩu không được bỏ trống", Toast.LENGTH_SHORT).show();
            return;
        }else {
            if (daoThuThu.checkLogin(strUser,strPass)>0 || (strUser.equals("admin")&& strPass.equals("admin"))){
                Toast.makeText(this, "Login thành công", Toast.LENGTH_SHORT).show();
                rememberUser(strUser,strPass,chk_luuThongTin.isChecked());
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                i.putExtra("user",strUser);
                startActivity(i);
                finish();
            }else {
                Toast.makeText(this, "Tên đăng nhập và mật khẩu không đúng", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void rememberUser(String u ,String p,boolean checked) {
        SharedPreferences preferences = getSharedPreferences("rememberLogin",MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        if (!checked){
            editor.clear();
        }else {
            editor.putString("user",u);
            editor.putString("pass",p);
            editor.putBoolean("checked",checked);
        }
        editor.commit();
    }

    private void addControl() {
        btn_login = findViewById(R.id.btn_login);
        btn_huy = findViewById(R.id.btn_huy);
        txt_user = findViewById(R.id.txt_user);
        txt_pass = findViewById(R.id.txt_pass);
        chk_luuThongTin = findViewById(R.id.chk_luuThongTin);
        daoThuThu = new DAOThuThu(LoginActivity.this);

    }
}