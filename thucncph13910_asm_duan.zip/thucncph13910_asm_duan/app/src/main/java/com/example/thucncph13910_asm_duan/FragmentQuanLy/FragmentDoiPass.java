package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.thucncph13910_asm_duan.Dao.DAOThuThu;
import com.example.thucncph13910_asm_duan.Model.ThuThu;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.textfield.TextInputEditText;

public class FragmentDoiPass extends Fragment {
    TextInputEditText txt_passold,txt_passnew,txt_repassnew;
    Button btn_doipass,btn_huypass;
    DAOThuThu daoThuThu;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doipass,container,false);
        txt_passold = view.findViewById(R.id.txt_passold);
        txt_passnew = view.findViewById(R.id.txt_passnew);
        txt_repassnew = view.findViewById(R.id.txt_repassnew);
        btn_doipass = view.findViewById(R.id.btn_doipass);
        btn_huypass = view.findViewById(R.id.btn_huypass);
        daoThuThu = new DAOThuThu(getContext());
        btn_huypass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txt_passold.setText("");
                txt_passnew.setText("");
                txt_repassnew.setText("");
            }
        });
        btn_doipass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences= getActivity().getSharedPreferences("rememberLogin",Context.MODE_PRIVATE);
                String user = preferences.getString("user","");
                if (validate()>0){
                    ThuThu thuThu = daoThuThu.getID(user);
                    thuThu.setMaKhau(txt_passnew.getText().toString());
                    daoThuThu.updateTT(thuThu);
                    if (daoThuThu.updateTT(thuThu)>0){
                        Toast.makeText(getContext(), "Thay đổi mật khẩu thành công", Toast.LENGTH_SHORT).show();
                        txt_passold.setText("");
                        txt_passnew.setText("");
                        txt_repassnew.setText("");
                    }else {
                        Toast.makeText(getContext(), "Thay đổi mật khẩu thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return view;
    }

    private int validate() {
        int check = 1;
        if (txt_passold.getText().length()==0 ||txt_passnew.getText().length()==0 || txt_repassnew.getText().length()==0){
            Toast.makeText(getContext(), "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            check = -1;
        }else {
            SharedPreferences preferences = getActivity().getSharedPreferences("rememberLogin",Context.MODE_PRIVATE);
            String passold = preferences.getString("pass","");
            String pass = txt_passnew.getText().toString();
            String repass = txt_repassnew.getText().toString();
            if (!passold.equals(txt_passold.getText().toString())){
                Toast.makeText(getContext(), "Mật khẩu cũ sai", Toast.LENGTH_SHORT).show();
                check = -1;
            }
            if (!pass.equals(repass)){
                Toast.makeText(getContext(), "Mật khẩu không trùng khớp", Toast.LENGTH_SHORT).show();
                check = -1;
            }

        }
        return check;
    }
}
