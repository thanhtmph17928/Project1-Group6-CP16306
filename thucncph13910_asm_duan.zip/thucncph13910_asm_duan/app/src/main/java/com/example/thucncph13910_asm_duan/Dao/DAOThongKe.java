package com.example.thucncph13910_asm_duan.Dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.Model.Top10;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DAOThongKe {
    SQLiteDatabase database;
    Context context;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    public DAOThongKe(Context context) {
        this.context = context;
        CreateDatabase createDatabase = new CreateDatabase(context);
        database=createDatabase.getWritableDatabase();
    }
    public ArrayList<Top10> getTop(){
        String sqlTop = "SELECT masach , count(masach) as soLuong FROM phieumuon GROUP BY masach ORDER BY soLuong DESC LIMIT 10";
        ArrayList<Top10> listTop = new ArrayList<>();
        DAOSach daoSach = new DAOSach(context);
        Cursor cursor = database.rawQuery(sqlTop,null);
        while (cursor.moveToNext()){
            Top10 top10 = new Top10();
            Sach sach = daoSach.getID(cursor.getString(cursor.getColumnIndex("masach")));
            top10.tenSach = sach.getTenSach();
            top10.soLuong = Integer.parseInt(cursor.getString(cursor.getColumnIndex("soLuong")));
            listTop.add(top10);
        }
        return listTop;
    }
    public  int getDoanhThu(String tuNgay,String denNgay){

        String sqlDT = "SELECT SUM(tienthue) as doanhThu FROM phieumuon WHERE ngaytra BETWEEN ? AND ? ";
        ArrayList<Integer> list = new ArrayList<>();
        Cursor cursor = database.rawQuery(sqlDT,new String[]{tuNgay,denNgay});
        while (cursor.moveToNext()){
            try {
                list.add(Integer.valueOf(cursor.getString(cursor.getColumnIndex("doanhThu"))));
            }catch (Exception e){
                list.add(0);
            }
        }
        return list.get(0);
    }

}
