package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterThanhVien;
import com.example.thucncph13910_asm_duan.Dao.DAOThanhVien;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class    FragmentThanhVien extends Fragment {
    RecyclerView recyclerView;
    FloatingActionButton btn_fThanhVien;
    DAOThanhVien daoThanhVien;
    ArrayList<ThanhVien> listTV;
    AdapterThanhVien adapterThanhVien;
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    @Override
    public View onCreateView( LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_thanhvien,container,false);
        recyclerView = view.findViewById(R.id.recycleviewTV);
        btn_fThanhVien = view.findViewById(R.id.btn_fThanhVien);
        daoThanhVien = new DAOThanhVien(getContext());
        listTV = new ArrayList<>();
        listTV = daoThanhVien.getAllTV();
        adapterThanhVien = new AdapterThanhVien(getContext(),listTV);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterThanhVien);

        btn_fThanhVien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.dialog_addthanhvien,null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_closeTV = view1.findViewById(R.id.btn_closeTV);
                Button btn_insertTV = view1.findViewById(R.id.btn_insertTV);
                EditText txt_tenTV = view1.findViewById(R.id.txt_tenTV);
                EditText txt_namsinhTV = view1.findViewById(R.id.txt_namsinhTV);
                txt_namsinhTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR,year);
                                calendar.set(Calendar.MONTH,month);
                                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                                txt_namsinhTV.setText(dateFormat.format(calendar.getTime()));
                            }
                        };
                        DatePickerDialog pickerDialog = new DatePickerDialog(getContext(),callback,calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                        pickerDialog.show();
                    }
                });
                btn_insertTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (txt_tenTV.getText().toString().trim().isEmpty()){
                            Toast.makeText(getContext(), "Không được bỏ trống tên thành viên", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_namsinhTV.getText().toString().trim().isEmpty()){
                            Toast.makeText(getContext(), "Không được bỏ trống năm sinh", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            ThanhVien thanhVien = new ThanhVien();
                            thanhVien.setHoTen(txt_tenTV.getText().toString());
                            thanhVien.setNamSinh(txt_namsinhTV.getText().toString());
                            long kq = daoThanhVien.insertTV(thanhVien);
                            if (kq>0){
                                listTV.clear();
                                listTV.addAll(daoThanhVien.getAllTV());
                                adapterThanhVien.notifyDataSetChanged();
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }
                    }
                });
                btn_closeTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
        return view;
    }
}
