package com.example.thucncph13910_asm_duan.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.PhieuMuon;

import java.util.ArrayList;

public class DAOPhieuMuon {
    CreateDatabase createDatabase;

    public DAOPhieuMuon(Context context) {
        createDatabase= new CreateDatabase(context);
    }
    public long insertPM(PhieuMuon phieuMuon){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhieuMuon.TABLE_MATV,phieuMuon.getMaTV());
        values.put(PhieuMuon.TABLE_MASACH,phieuMuon.getMaSach());
        values.put(PhieuMuon.TABLE_NGAYTRA,phieuMuon.getNgaytra());
        values.put(PhieuMuon.TABLE_TRASACH,phieuMuon.getTraSach());
        values.put(PhieuMuon.TABLE_TIENTHUE,phieuMuon.getTienThue());

        long kq = database.insert(PhieuMuon.TABLE_NAME_PM,null,values);
        return kq;
    }
    public int updatePM(PhieuMuon phieuMuon){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PhieuMuon.TABLE_MATV,phieuMuon.getMaTV());
        values.put(PhieuMuon.TABLE_MASACH,phieuMuon.getMaSach());
        values.put(PhieuMuon.TABLE_NGAYTRA,phieuMuon.getNgaytra());
        values.put(PhieuMuon.TABLE_TRASACH,phieuMuon.getTraSach());
        values.put(PhieuMuon.TABLE_TIENTHUE,phieuMuon.getTienThue());

        int kq = database.update(PhieuMuon.TABLE_NAME_PM,values,"mapm =? ",new String[]{String.valueOf(phieuMuon.getMaPM())});
        return kq;
    }
    public int deletePM(int id){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        int kq = database.delete(PhieuMuon.TABLE_NAME_PM,"mapm =? ",new String[]{String.valueOf(id)});
        return kq;
    }
    public ArrayList<PhieuMuon> getAllPM(){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<PhieuMuon> listPM = new ArrayList<>();
        String select = "SELECT * FROM " + PhieuMuon.TABLE_NAME_PM;
        Cursor cursor = database.rawQuery(select,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int mapm = cursor.getInt(0);
            int matv = cursor.getInt(1);
            int masach = cursor.getInt(2);
            String matt = cursor.getString(3);
            String ngaytra = cursor.getString(4);
            int trasach = cursor.getInt(5);
            int tienthue = cursor.getInt(6);


            PhieuMuon phieuMuon = new PhieuMuon(mapm,matv,masach,matt,ngaytra,trasach,tienthue);
            listPM.add(phieuMuon);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listPM;
    }
}
