package com.example.thucncph13910_asm_duan.Adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.R;

public class ViewHolderThanhVien extends RecyclerView.ViewHolder {
    ImageView img_deleteTV;
    TextView tvTenTV,tvNamSinhTV;
    CardView cv_thanhvien;
    public ViewHolderThanhVien(View itemView) {
        super(itemView);
        img_deleteTV = itemView.findViewById(R.id.img_deleteTV);
        tvTenTV = itemView.findViewById(R.id.tvTenTV);
        tvNamSinhTV = itemView.findViewById(R.id.tvNamSinhTV);
        cv_thanhvien = itemView.findViewById(R.id.cv_thanhvien);
    }
}
