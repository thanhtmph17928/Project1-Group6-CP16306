package com.example.thucncph13910_asm_duan.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.Sach;

import java.util.ArrayList;

public class DAOSach {
    CreateDatabase createDatabase;

    public DAOSach(Context context) {
        createDatabase = new CreateDatabase(context);
    }

    public long insertSach(Sach sach){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Sach.TABLE_TENSACH,sach.getTenSach());
        values.put(Sach.TABLE_GIATHUE,sach.getGiaThue());
        values.put(Sach.TABLE_SOTRANG,sach.getSotrang());
        values.put(Sach.TABLE_MALOAI,sach.getMaLoai());
        long kq = database.insert(Sach.TABLE_NAME_S,null,values);
        return kq;
    }
    public int updateSach(Sach sach){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Sach.TABLE_TENSACH,sach.getTenSach());
        values.put(Sach.TABLE_GIATHUE,sach.getGiaThue());
        values.put(Sach.TABLE_SOTRANG,sach.getSotrang());
        values.put(Sach.TABLE_MALOAI,sach.getMaLoai());
        int kq = database.update(Sach.TABLE_NAME_S,values,"masach = ? ",new String[]{String.valueOf(sach.getMaSach())});
        return kq;
    }
    public int deleteSach(int id){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        int kq = database.delete(Sach.TABLE_NAME_S,"masach = ? ",new String[]{String.valueOf(id)});
        return kq;
    }
    public ArrayList<Sach> getAllDK(String sql , String... a){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<Sach> listS = new ArrayList<>();
        Cursor cursor = database.rawQuery(sql,a);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int masach = cursor.getInt(0);
            String tensach = cursor.getString(1);
            int giathue = cursor.getInt(2);
            int sotrang = cursor.getInt(3);
            int maloai = cursor.getInt(4);
            Sach sach = new Sach(masach,tensach,giathue,sotrang,maloai);
            listS.add(sach);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listS;
    }
    public Sach getID(String id){
        String sele = "SELECT * FROM sach WHERE masach =? ";
        ArrayList<Sach> listS = getAllDK(sele, String.valueOf(id));
        return listS.get(0);
    }
    public ArrayList<Sach> getAllSach(){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<Sach> listS = new ArrayList<>();
        Cursor cursor = database.query(Sach.TABLE_NAME_S,null,null,null,null,null,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int masach = cursor.getInt(0);
            String tensach = cursor.getString(1);
            int giathue = cursor.getInt(2);
            int sotrang = cursor.getInt(3);
            int maloai = cursor.getInt(4);
            Sach sach = new Sach(masach,tensach,giathue,sotrang,maloai);
            listS.add(sach);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listS;
    }
    public ArrayList<Sach> getIDSach(int id){
        String sele = "SELECT * FROM sach as s INNER JOIN phieumuon as pm ON s.masach = pm.masach WHERE s.masach =? ";
        ArrayList<Sach> list = getAllDK(sele, String.valueOf(id));
        return list;
    }
    public ArrayList<Sach> getSearch(String num){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<Sach> list = new ArrayList<>();
        String sql = "SELECT * FROM sach WHERE sach.sotrang > 1000";
        //LIKE '%"+num+"%'
        Cursor cursor = database.rawQuery(sql,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int masach = cursor.getInt(0);
            String tensach = cursor.getString(1);
            int giathue = cursor.getInt(2);
            int sotrang = cursor.getInt(3);
            int maloai = cursor.getInt(4);
            Sach sach = new Sach(masach,tensach,giathue,sotrang,maloai);
            list.add(sach);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return list;
    }

}
