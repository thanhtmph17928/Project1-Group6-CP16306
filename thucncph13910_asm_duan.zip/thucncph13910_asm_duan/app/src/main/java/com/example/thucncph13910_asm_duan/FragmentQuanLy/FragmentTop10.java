package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterTop10;
import com.example.thucncph13910_asm_duan.Dao.DAOThongKe;
import com.example.thucncph13910_asm_duan.Model.Top10;
import com.example.thucncph13910_asm_duan.R;

import java.util.ArrayList;

public class FragmentTop10 extends Fragment {
    AdapterTop10 adapterTop10;
    ArrayList<Top10> listTop10;
    RecyclerView recyclerView;
    DAOThongKe daoThongKe;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_top10,container,false);
        recyclerView = view.findViewById(R.id.reccycleviewTop);
        listTop10 = new ArrayList<>();
        daoThongKe = new DAOThongKe(getContext());
        listTop10 = daoThongKe.getTop();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        adapterTop10 = new AdapterTop10(getContext(),listTop10);
        recyclerView.setAdapter(adapterTop10);

        return view;
    }
}
