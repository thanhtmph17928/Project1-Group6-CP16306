package com.example.thucncph13910_asm_duan.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.Model.PhieuMuon;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;
import com.example.thucncph13910_asm_duan.Model.ThuThu;

public class CreateDatabase extends SQLiteOpenHelper {
    public static final String DBNAME = "qlthuvien.db";

    public CreateDatabase(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override // sum(tienthue*khuyenmai)
    public void onCreate(SQLiteDatabase db) {
        //create table Phiếu mượn
        String TABLE_PHIEUMUON = "CREATE TABLE phieumuon ( " +
                "mapm INTEGER PRIMARY KEY AUTOINCREMENT ,matv INTEGER REFERENCES thanhvien(matv) , " +
                "masach INTEGER REFERENCES sach(masach),matt TEXT REFERENCES thuthu(matt) ," +
                "ngaytra DATE NOT NULL ,trasach INTEGER NOT NULL , tienthue INTEGER NOT NULL  )";
        db.execSQL(TABLE_PHIEUMUON);

        //create table loại sách
        String TABLE_LOAISACH = "CREATE TABLE loaisach(" +
                "maloai INTEGER PRIMARY KEY AUTOINCREMENT , " +
                "hoten TEXT NOT NULL)";
        db.execSQL(TABLE_LOAISACH);

        //create table sách
        String TABLE_SACH = "CREATE TABLE sach(" +
                "masach INTEGER PRIMARY KEY AUTOINCREMENT , " +
                "tensach TEXT NOT NULL ," +
                "giathue INTEGER NOT NULL, sotrang INTEGER NOT NULL," +
                "maloai INTEGER REFERENCES loaisach(maloai))";
        db.execSQL(TABLE_SACH);

        //create table Thành viên
        String TABLE_THANHVIEN = "CREATE TABLE thanhvien(" +
                "matv INTEGER PRIMARY KEY AUTOINCREMENT , " +
                "hoten TEXT NOT NULL , " +
                "namsinh DATE NOT NULL)";
        db.execSQL(TABLE_THANHVIEN);

        //create table thủ thư
        String TABLE_THUTHU = "CREATE TABLE thuthu(" +
                "matt TEXT PRIMARY KEY NOT NULL, " +
                "hoten TEXT NOT NULL, " +
                "matkhau TEXT NOT NULL )";
        db.execSQL(TABLE_THUTHU);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String drop_phieumuon = "DROP TABLE IF EXISTS " + PhieuMuon.TABLE_NAME_PM;
        db.execSQL(drop_phieumuon);
        String drop_loaisach = "DROP TABLE IF EXISTS " + LoaiSach.TABLE_NAME_LS;
        db.execSQL(drop_loaisach);
        String drop_sach = "DROP TABLE IF EXISTS " + Sach.TABLE_NAME_S;
        db.execSQL(drop_sach);
        String drop_thanhvien = "DROP TABLE IF EXISTS " + ThanhVien.TABLE_NAME_TV;
        db.execSQL(drop_thanhvien);
        String drop_thuthu = "DROP TABLE IF EXISTS " + ThuThu.TABLE_NAME_TT;
        db.execSQL(drop_thuthu);
    }
}
