package com.example.thucncph13910_asm_duan.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.Model.Sach;

import java.util.ArrayList;
import java.util.List;

public class DAOLoaiSach {
    CreateDatabase crDatabase;

    public DAOLoaiSach(Context context) {
        crDatabase = new CreateDatabase(context);
    }

    public long insertLoaiSach(LoaiSach loaiSach) {
        SQLiteDatabase database = crDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoaiSach.TABLE_HOTEN, loaiSach.getHoTen());
        long kq = database.insert(LoaiSach.TABLE_NAME_LS, null, values);
        return kq;
    }

    public int updateLoaiSach(LoaiSach loaiSach) {
        SQLiteDatabase database = crDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoaiSach.TABLE_HOTEN, loaiSach.getHoTen());
        int kq = database.update(LoaiSach.TABLE_NAME_LS, values, "maloai = ? ", new String[]{String.valueOf(loaiSach.getMaLoai())});
        return kq;
    }

    public int deleteLoaiSach(int id) {
        SQLiteDatabase database = crDatabase.getWritableDatabase();
        int kq = database.delete(LoaiSach.TABLE_NAME_LS, "maloai = ? ", new String[]{String.valueOf(id)});
        return kq;
    }

    public ArrayList<LoaiSach> getAllDK(String sql , String... a) {
        SQLiteDatabase database = crDatabase.getReadableDatabase();
        ArrayList<LoaiSach> listLS = new ArrayList<>();
//        String select = "SELECT * FROM " + LoaiSach.TABLE_NAME_LS;
        Cursor cursor = database.rawQuery(sql, a);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int ma = cursor.getInt(0);
            String ten = cursor.getString(1);
            LoaiSach loaiSach = new LoaiSach(ma, ten);
            listLS.add(loaiSach);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listLS;
    }
    public ArrayList<LoaiSach> getAllLS(){
        String select = "SELECT * FROM " + LoaiSach.TABLE_NAME_LS;
        return getAllDK(select);
    }
    public LoaiSach getID(int id){
        String sele = "SELECT * FROM loaisach WHERE maloai =? ";
        ArrayList<LoaiSach> list =getAllDK(sele, String.valueOf(id));
        return list.get(0);
    }
    public ArrayList<LoaiSach> getIDLS(int id){
        String sele = "SELECT * FROM loaisach as ls INNER JOIN sach as s ON ls.maloai = s.maloai WHERE ls.maloai =? ";
        ArrayList<LoaiSach> list = getAllDK(sele, String.valueOf(id));
        return list;
    }
}
