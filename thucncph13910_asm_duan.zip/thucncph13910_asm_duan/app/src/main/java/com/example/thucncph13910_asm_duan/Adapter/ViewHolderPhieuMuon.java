package com.example.thucncph13910_asm_duan.Adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.R;

public class ViewHolderPhieuMuon extends RecyclerView.ViewHolder {
    CardView cardView;
    TextView tv_mapm,tv_tentv,tv_tensach,tv_tienthue,tv_trasach,tv_ngaythue;
    ImageView img_deletePM;
    public ViewHolderPhieuMuon(View itemView) {
        super(itemView);
        tv_mapm = itemView.findViewById(R.id.tv_mapm);
        tv_tentv = itemView.findViewById(R.id.tv_tentv);
        tv_tensach = itemView.findViewById(R.id.tv_tensach);
        tv_tienthue = itemView.findViewById(R.id.tv_tienthue);
        tv_trasach = itemView.findViewById(R.id.tv_trasach);
        tv_ngaythue = itemView.findViewById(R.id.tv_ngaythue);
        img_deletePM = itemView.findViewById(R.id.img_deletePM);
        cardView = itemView.findViewById(R.id.cv_phieumuon);
    }
}
