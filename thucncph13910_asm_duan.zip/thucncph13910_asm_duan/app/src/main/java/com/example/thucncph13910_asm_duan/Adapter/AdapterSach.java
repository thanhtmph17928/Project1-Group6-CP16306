package com.example.thucncph13910_asm_duan.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Dao.DAOLoaiSach;
import com.example.thucncph13910_asm_duan.Dao.DAOSach;
import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.R;

import java.util.ArrayList;

public class AdapterSach extends RecyclerView.Adapter<ViewHolderSach> {
    Context context;
    ArrayList<Sach> listS;
    DAOSach daoSach;
    ArrayList<LoaiSach> listLS = new ArrayList<>();
    DAOLoaiSach daoLoaiSach;

    public AdapterSach(Context context, ArrayList<Sach> listS) {
        this.context = context;
        this.listS = listS;
        daoSach = new DAOSach(context);
        daoLoaiSach = new DAOLoaiSach(context);
    }

    @Override
    public ViewHolderSach onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_sach, null);
        return new ViewHolderSach(view);
    }

    @Override
    public void onBindViewHolder(ViewHolderSach holder, int position) {
        Sach sach = listS.get(position);
        holder.tvTenSach.setText("Tên: " + sach.getTenSach());
        LoaiSach loaiSach = daoLoaiSach.getID(sach.getMaLoai());
        holder.tvTenLoaiSach.setText("Loại: " + loaiSach.getHoTen());
        holder.tvGiaThue.setText("Giá: " + sach.getGiaThue() + "đ");
        holder.tvSoTrang.setText("Trang: "+sach.getSotrang());
        if (sach.getSotrang()>1000){
            holder.tvSoTrang.setTypeface(null, Typeface.BOLD);
        }

        holder.cv_sach.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.dialog_updatesach, null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_updateS = view1.findViewById(R.id.btn_updateS);
                Button btn_closeUS = view1.findViewById(R.id.btn_closeUS);
                EditText txt_updatetenS = view1.findViewById(R.id.txt_updatetenS);
                EditText txt_updategiathueS = view1.findViewById(R.id.txt_updategiathueS);
                EditText txt_updatesotrangS = view1.findViewById(R.id.txt_updatesotrangS);

                Spinner spn_updatemaloai = view1.findViewById(R.id.spn_updatemaloai);

                //đổ dữ liệu vào spinner
                listLS = daoLoaiSach.getAllLS();
                ArrayAdapter adapter = new ArrayAdapter(view.getContext(), android.R.layout.simple_list_item_1, listLS);
                spn_updatemaloai.setAdapter(adapter);


                txt_updatetenS.setText(sach.getTenSach());
                txt_updategiathueS.setText(String.valueOf(sach.getGiaThue()));
                txt_updatesotrangS.setText(String.valueOf(sach.getSotrang()));
                int posi = -1;
                for (int i = 0; i < listLS.size(); i++) {
                    if (listLS.get(i).getMaLoai() == loaiSach.getMaLoai()) {
                        posi = i;
                        break;
                    }
                }
                spn_updatemaloai.setSelection(posi);
                btn_updateS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (listLS.size() <= 0) {
                            Toast.makeText(view.getContext(), "Chưa có Loại Sách , vui lòng thêm loại sách trước", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (txt_updatetenS.getText().toString().trim().isEmpty()) {
                            Toast.makeText(view.getContext(), "Không được bỏ trống tên sách", Toast.LENGTH_SHORT).show();
                            return;
                        } else if (txt_updategiathueS.getText().toString().trim().isEmpty()) {
                            Toast.makeText(view.getContext(), "Không được bỏ trống giá thuê", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            sach.setTenSach(txt_updatetenS.getText().toString());
                            sach.setGiaThue(Integer.parseInt(txt_updategiathueS.getText().toString()));
                            sach.setSotrang(Integer.parseInt(txt_updatesotrangS.getText().toString()));
                            LoaiSach loaiSach = (LoaiSach) spn_updatemaloai.getSelectedItem();
                            sach.setMaLoai(loaiSach.getMaLoai());
                            int kq = daoSach.updateSach(sach);
                            if (kq > 0) {
                                listS.clear();
                                listS.addAll(daoSach.getAllSach());
                                notifyDataSetChanged();
                                Toast.makeText(view.getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            } else {
                                Toast.makeText(view.getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }
                });
                btn_closeUS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                return false;
            }
        });
        holder.img_deleteS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete, null);
                builder1.setView(view1);
                builder1.setCancelable(false);
                AlertDialog alertDialog1 = builder1.create();
                alertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog1.show();
                Button button = view1.findViewById(R.id.btn_closee);
                ImageView imageView = view1.findViewById(R.id.img_closee);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog1.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ArrayList<Sach> listSach = daoSach.getIDSach(sach.getMaSach());
                        if (listSach.size()>0){
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                            View view11 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete_child,null);
                            builder.setCancelable(false);
                            builder.setView(view11);
                            AlertDialog  alertDialog = builder.create();
                            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            alertDialog.show();
                            Button btn_closechild = view11.findViewById(R.id.btn_closechild);
                            btn_closechild.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    alertDialog.dismiss();
                                    alertDialog1.dismiss();
                                }
                            });
                            return;
                        }else {
                            int kq = daoSach.deleteSach(sach.getMaSach());
                            if (kq > 0) {
                                listS.clear();
                                listS.addAll(daoSach.getAllSach());
                                notifyDataSetChanged();
                                Toast.makeText(view1.getContext(), "Xóa thành công ", Toast.LENGTH_SHORT).show();
                                alertDialog1.dismiss();
                            } else {
                                Toast.makeText(view1.getContext(), "Xóa thất bại ", Toast.LENGTH_SHORT).show();
                                alertDialog1.dismiss();
                            }
                        }

                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return listS.size();
    }
}
