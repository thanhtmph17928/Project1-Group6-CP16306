package com.example.thucncph13910_asm_duan.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Model.Top10;
import com.example.thucncph13910_asm_duan.R;

import java.util.ArrayList;

public class AdapterTop10 extends RecyclerView.Adapter<ViewHolderTop10> {
    Context context;
    ArrayList<Top10> listTop10;

    public AdapterTop10(Context context, ArrayList<Top10> listTop10) {
        this.context = context;
        this.listTop10 = listTop10;
    }

    @Override
    public ViewHolderTop10 onCreateViewHolder(ViewGroup parent, int viewType) {
        View view1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_top10,null);
        return new ViewHolderTop10(view1);
    }

    @Override
    public void onBindViewHolder(ViewHolderTop10 holder, int position) {
        Top10 top10 = listTop10.get(position);
        holder.tvtensachTop10.setText("Sách: "+ top10.tenSach);
        holder.tvsoluongTop10.setText("Số lượng: " + top10.soLuong);
    }

    @Override
    public int getItemCount() {
        return listTop10.size();
    }
}
