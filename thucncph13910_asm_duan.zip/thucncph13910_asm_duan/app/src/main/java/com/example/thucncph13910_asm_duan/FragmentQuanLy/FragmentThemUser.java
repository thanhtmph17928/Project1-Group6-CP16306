package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterThemUser;
import com.example.thucncph13910_asm_duan.Dao.DAOThuThu;
import com.example.thucncph13910_asm_duan.MainActivity;
import com.example.thucncph13910_asm_duan.Model.OnSearchListener;
import com.example.thucncph13910_asm_duan.Model.ThuThu;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FragmentThemUser extends Fragment {
    Button btn_themuser,btn_huy;
    TextInputEditText txt_tendangnhap,txt_hoten,txt_pass,txt_repass;
    DAOThuThu daoThuThu;
    FloatingActionButton actionButton;
    AdapterThemUser adapterThemUser;
    RecyclerView recyclerView;
    ArrayList<ThuThu> listTT;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_themuser,container,false);
        actionButton = view.findViewById(R.id.btnf_themuser);
        recyclerView = view.findViewById(R.id.recycleview_themuser);
        listTT = new ArrayList<>();
        daoThuThu = new DAOThuThu(getContext());
        listTT = daoThuThu.getAllTT();
        adapterThemUser = new AdapterThemUser(getContext(),listTT);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterThemUser);
        actionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setCancelable(false);
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.dialog_themuser,null);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                btn_themuser = view1.findViewById(R.id.btn_themuser);
                btn_huy = view1.findViewById(R.id.btn_huy);
                txt_tendangnhap = view1.findViewById(R.id.txt_tendangnhap);
                txt_hoten = view1.findViewById(R.id.txt_hoten);
                txt_pass = view1.findViewById(R.id.txt_pass);
                txt_repass = view1.findViewById(R.id.txt_repass);

                btn_themuser.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (txt_tendangnhap.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "Tên đăng nhập không được bỏ trống", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_hoten.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "Họ và tên không được bỏ trống", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_pass.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "Mật khẩu không được bỏ trống", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_repass.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "Nhập lại mật khẩu", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (!txt_repass.getText().toString().equals(txt_pass.getText().toString())){
                            Toast.makeText(getContext(), "Mật khẩu không khớp", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            ThuThu thuThu = new ThuThu();
                            thuThu.setMaTT(txt_tendangnhap.getText().toString());
                            thuThu.setHoTen(txt_hoten.getText().toString());
                            thuThu.setMaKhau(txt_pass.getText().toString());
                            long kq = daoThuThu.insertTT(thuThu);
                            if (kq>0){
                                listTT.clear();
                                listTT.addAll(daoThuThu.getAllTT());
                                adapterThemUser.notifyDataSetChanged();
                                Toast.makeText(getContext(), "Thêm người dùng thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(getContext(), "Thêm người dùng thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }
                    }
                });
            }
        });

        return view;
    }
}
