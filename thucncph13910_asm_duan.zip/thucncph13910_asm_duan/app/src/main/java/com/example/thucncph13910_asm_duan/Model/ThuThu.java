package com.example.thucncph13910_asm_duan.Model;

public class ThuThu {
    String maTT, hoTen, maKhau;
    public static final String TABLE_NAME_TT = "thuthu";
    public static final String TABLE_MATT = "matt";
    public static final String TABLE_HOTEN = "hoten";
    public static final String TABLE_MATKHAU = "matkhau";

    public ThuThu() {
    }

    public ThuThu(String maTT, String hoTen, String maKhau) {
        this.maTT = maTT;
        this.hoTen = hoTen;
        this.maKhau = maKhau;
    }

    public String getMaTT() {
        return maTT;
    }

    public void setMaTT(String maTT) {
        this.maTT = maTT;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getMaKhau() {
        return maKhau;
    }

    public void setMaKhau(String maKhau) {
        this.maKhau = maKhau;
    }
}
