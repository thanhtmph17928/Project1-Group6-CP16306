package com.example.thucncph13910_asm_duan.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Dao.DAOLoaiSach;
import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.R;

import java.util.ArrayList;

public class AdapterLoaiSach extends RecyclerView.Adapter<ViewHolderLoaiSach> {
    Context context;
    ArrayList<LoaiSach> listLS;
    DAOLoaiSach daoLoaiSach;

    public AdapterLoaiSach(Context context, ArrayList<LoaiSach> listLS) {
        this.context = context;
        this.listLS = listLS;
        daoLoaiSach = new DAOLoaiSach(context);
    }

    @Override
    public ViewHolderLoaiSach onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_loaisach, null);
        return new ViewHolderLoaiSach(view);
    }

    @Override
    public void onBindViewHolder(ViewHolderLoaiSach holder, int position) {
        LoaiSach loaiSach = listLS.get(position);
        holder.tvCustomLoaiSach.setText(loaiSach.getHoTen());
        holder.cv_loaisach.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.dialog_updatels, null);
                builder.setView(view1);
                builder.setCancelable(false);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_updateLS = view1.findViewById(R.id.btn_updateLS);
                Button btnCloseUpdate = view1.findViewById(R.id.btnCloseUpdate);
                EditText txt_updateTenLS = view1.findViewById(R.id.txt_updateTenLS);

                txt_updateTenLS.setText(loaiSach.getHoTen());

                btnCloseUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btn_updateLS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        loaiSach.setHoTen(txt_updateTenLS.getText().toString());
                        if (txt_updateTenLS.getText().toString().trim().isEmpty()) {
                            Toast.makeText(view.getContext(), "Không được bỏ trống tên loại sách", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            long kq = daoLoaiSach.updateLoaiSach(loaiSach);
                            if (kq > 0) {
                                listLS.clear();
                                listLS.addAll(daoLoaiSach.getAllLS());
                                notifyDataSetChanged();
                                Toast.makeText(view1.getContext(), "Cập nhật thành công ", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            } else {
                                Toast.makeText(view1.getContext(), "Cập nhật thất bại ", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                });
                return false;
            }
        });
        holder.img_deleteLS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete, null);
                builder1.setView(view1);
                builder1.setCancelable(false);
                AlertDialog alertDialog = builder1.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button button = view1.findViewById(R.id.btn_closee);
                ImageView imageView = view1.findViewById(R.id.img_closee);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ArrayList<LoaiSach> list = daoLoaiSach.getIDLS(loaiSach.getMaLoai());
                        if (list.size() > 0) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                            View view2 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete_child, null);
                            builder.setCancelable(false);
                            builder.setView(view2);
                            AlertDialog alertDialog1 = builder.create();
                            alertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            alertDialog1.show();

                            Button button1 = view2.findViewById(R.id.btn_closechild);
                            button1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    alertDialog.dismiss();
                                    alertDialog1.dismiss();
                                }
                            });
                            return;
                        }else {
                            int kq = daoLoaiSach.deleteLoaiSach(loaiSach.getMaLoai());
                            if (kq > 0) {
                                listLS.clear();
                                listLS.addAll(daoLoaiSach.getAllLS());
                                notifyDataSetChanged();
                                Toast.makeText(view1.getContext(), "Xóa thành công ", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            } else {
                                Toast.makeText(view1.getContext(), "Xóa thất bại ", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }

                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return listLS.size();
    }
}
