package com.example.thucncph13910_asm_duan.Adapter;

import android.graphics.Paint;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.R;

public class ViewHolderSach extends RecyclerView.ViewHolder {
    TextView tvTenSach,tvTenLoaiSach,tvGiaThue,tvSoTrang;
    ImageView img_deleteS;
    CardView cv_sach;
    public ViewHolderSach(View itemView) {
        super(itemView);
        tvTenSach = itemView.findViewById(R.id.tvTenSach);
        tvTenLoaiSach = itemView.findViewById(R.id.tvTenLoaiSach);
        tvGiaThue = itemView.findViewById(R.id.tvGiaThue);
        tvSoTrang = itemView.findViewById(R.id.tvSoTrang);
//        tvGiaThue.setPaintFlags(tvGiaThue.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        img_deleteS = itemView.findViewById(R.id.img_deleteS);
        cv_sach = itemView.findViewById(R.id.cv_sach);
    }
}
