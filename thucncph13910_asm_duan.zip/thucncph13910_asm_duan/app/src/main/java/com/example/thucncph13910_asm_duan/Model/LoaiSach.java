package com.example.thucncph13910_asm_duan.Model;

public class LoaiSach {
    int maLoai;
    String hoTen;

    public static final String TABLE_NAME_LS = "loaisach";
    public static final String TABLE_MALOAI = "maloai";
    public static final String TABLE_HOTEN = "hoten";

    public LoaiSach() {
    }

    public LoaiSach(int maLoai, String hoTen) {
        this.maLoai = maLoai;
        this.hoTen = hoTen;
    }

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    @Override
    public String toString() {
        return this.getHoTen();
    }
}
