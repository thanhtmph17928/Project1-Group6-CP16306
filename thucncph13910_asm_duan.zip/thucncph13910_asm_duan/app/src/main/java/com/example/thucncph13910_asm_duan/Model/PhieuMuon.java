package com.example.thucncph13910_asm_duan.Model;

public class PhieuMuon {
    int maPM;
    int maTV;
    int maSach;
    String maTT;
    String ngaytra;
    int traSach;
    int tienThue;

    public static final String TABLE_NAME_PM = "phieumuon";
    public static final String TABLE_MAPM = "mapm";
    public static final String TABLE_MATT = "matt";
    public static final String TABLE_MATV = "matv";
    public static final String TABLE_MASACH = "masach";
    public static final String TABLE_NGAYTRA = "ngaytra";
    public static final String TABLE_TRASACH = "trasach";
    public static final String TABLE_TIENTHUE = "tienthue";


    public PhieuMuon() {
    }

    public PhieuMuon(int maPM, int maTV, int maSach, String maTT, String ngaytra, int traSach, int tienThue) {
        this.maPM = maPM;
        this.maTV = maTV;
        this.maSach = maSach;
        this.maTT = maTT;
        this.ngaytra = ngaytra;
        this.traSach = traSach;
        this.tienThue = tienThue;

    }

    public int getMaPM() {
        return maPM;
    }

    public void setMaPM(int maPM) {
        this.maPM = maPM;
    }

    public String getMaTT() {
        return maTT;
    }

    public void setMaTT(String maTT) {
        this.maTT = maTT;
    }

    public int getMaTV() {
        return maTV;
    }

    public void setMaTV(int maTV) {
        this.maTV = maTV;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public String getNgaytra() {
        return ngaytra;
    }

    public void setNgaytra(String ngaytra) {
        this.ngaytra = ngaytra;
    }

    public int getTraSach() {
        return traSach;
    }

    public void setTraSach(int traSach) {
        this.traSach = traSach;
    }

    public int getTienThue() {
        return tienThue;
    }

    public void setTienThue(int tienThue) {
        this.tienThue = tienThue;
    }

}
