package com.example.thucncph13910_asm_duan.Adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Dao.DAOThanhVien;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;
import com.example.thucncph13910_asm_duan.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class AdapterThanhVien extends RecyclerView.Adapter<ViewHolderThanhVien> {
    Context context;
    ArrayList<ThanhVien> listTV;
    DAOThanhVien daoThanhVien;
    int row_index = -1;
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    public AdapterThanhVien(Context context, ArrayList<ThanhVien> listTV) {
        this.context = context;
        this.listTV = listTV;
        daoThanhVien = new DAOThanhVien(context);
    }


    @Override
    public ViewHolderThanhVien onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_thanhvien,null);
        return new ViewHolderThanhVien(view);
    }

    @Override
    public void onBindViewHolder(ViewHolderThanhVien holder, int position) {
        ThanhVien thanhVien = listTV.get(position);

        holder.tvTenTV.setText("Họ và tên: " + thanhVien.getHoTen());
        holder.tvNamSinhTV.setText("Năm sinh: " + thanhVien.getNamSinh());
        holder.cv_thanhvien.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.dialog_updatethanhvien,null);
                builder.setView(view1);
                builder.setCancelable(false);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_updateTV = view1.findViewById(R.id.btn_updateTV);
                Button btn_closeUTV = view1.findViewById(R.id.btn_closeUTV);
                EditText txt_updatetenTV = view1.findViewById(R.id.txt_updatetenTV);
                EditText txt_updatenamsinhTV = view1.findViewById(R.id.txt_updatenamsinhTV);
                txt_updatenamsinhTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR,year);
                                calendar.set(Calendar.MONTH,month);
                                calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                                txt_updatenamsinhTV.setText(dateFormat.format(calendar.getTime()));
                            }
                        };
                        DatePickerDialog pickerDialog = new DatePickerDialog(view1.getContext(),callback,calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                        pickerDialog.show();
                    }
                });
                txt_updatetenTV.setText(thanhVien.getHoTen());
                txt_updatenamsinhTV.setText(thanhVien.getNamSinh());
                btn_closeUTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btn_updateTV.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (txt_updatetenTV.getText().toString().trim().isEmpty()){
                            Toast.makeText(view.getContext(), "Không được bỏ trống tên thành viên", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_updatenamsinhTV.getText().toString().trim().isEmpty()){
                            Toast.makeText(view.getContext(), "Không được bỏ trống năm sinh", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            thanhVien.setHoTen(txt_updatetenTV.getText().toString());
                            thanhVien.setNamSinh(txt_updatenamsinhTV.getText().toString());
                            int kq = daoThanhVien.updateTV(thanhVien);
                            if (kq>0){
                                listTV.clear();
                                listTV.addAll(daoThanhVien.getAllTV());
                                notifyDataSetChanged();
                                Toast.makeText(view1.getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(view1.getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }
                });
                return false;
            }
        });
        holder.img_deleteTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                View view1 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete,null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_closee = view1.findViewById(R.id.btn_closee);
                ImageView img_closee = view1.findViewById(R.id.img_closee);
                img_closee.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                btn_closee.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ArrayList<ThanhVien> listTv = daoThanhVien.getIDTV(thanhVien.getMaTV());
                        if (listTv.size()>0){
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                            View view11 = LayoutInflater.from(view.getContext()).inflate(R.layout.custom_delete_child,null);
                            builder.setCancelable(false);
                            builder.setView(view11);
                            AlertDialog  alertDialog1 = builder.create();
                            alertDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            alertDialog1.show();
                            Button btn_closechild = view11.findViewById(R.id.btn_closechild);
                            btn_closechild.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    alertDialog.dismiss();
                                    alertDialog1.dismiss();
                                }
                            });
                            return;
                        }else {
                            int kq = daoThanhVien.deleteTV(thanhVien.getMaTV());
                            if (kq > 0){
                                listTV.clear();
                                listTV.addAll(daoThanhVien.getAllTV());
                                notifyDataSetChanged();
                                Toast.makeText(view1.getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(view1.getContext(), "Xóa thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }
                });
            }
        });
//        holder.cv_thanhvien.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                row_index = position;
//                notifyDataSetChanged();
//            }
//        });
//        if (row_index==position){
//            holder.cv_thanhvien.setBackgroundColor(Color.RED);
//        }else {
//            holder.cv_thanhvien.setBackgroundColor(Color.GREEN);
//        }

    }

    @Override
    public int getItemCount() {
        return listTV.size();
    }
}
