package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterPhieuMuon;
import com.example.thucncph13910_asm_duan.Dao.DAOPhieuMuon;
import com.example.thucncph13910_asm_duan.Dao.DAOSach;
import com.example.thucncph13910_asm_duan.Dao.DAOThanhVien;
import com.example.thucncph13910_asm_duan.Dao.DAOThuThu;
import com.example.thucncph13910_asm_duan.Model.PhieuMuon;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.Model.ThanhVien;
import com.example.thucncph13910_asm_duan.Model.ThuThu;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class FragmentPhieuMuon extends Fragment {
    RecyclerView recyclerView;
    FloatingActionButton btn_fPhieuMuon;
    DAOPhieuMuon daoPhieuMuon;
    DAOThanhVien daoThanhVien;
    DAOSach daoSach;
    ArrayList<PhieuMuon> listPM;
    ArrayList<ThanhVien> listTV;
    ArrayList<Sach> listS;
    AdapterPhieuMuon adapterPhieuMuon;
    PhieuMuon phieuMuon;
    int masach, tienthue;
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_phieumuon, container, false);
        recyclerView = view.findViewById(R.id.recycleviewPM);
        btn_fPhieuMuon = view.findViewById(R.id.btn_fPhieuMuon);
        phieuMuon = new PhieuMuon();
        listPM = new ArrayList<>();
        listTV = new ArrayList<>();
        listS = new ArrayList<>();
        daoThanhVien = new DAOThanhVien(getContext());
        daoSach = new DAOSach(getContext());
        daoPhieuMuon = new DAOPhieuMuon(getContext());
        listPM = daoPhieuMuon.getAllPM();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        adapterPhieuMuon = new AdapterPhieuMuon(getContext(), listPM);
        recyclerView.setAdapter(adapterPhieuMuon);
        btn_fPhieuMuon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.dialog_addphieumuon, null);
                builder.setCancelable(false);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_insertPM = view1.findViewById(R.id.btn_insertPM);
                Button btn_closePM = view1.findViewById(R.id.btn_closePM);
                EditText txt_ngaytra = view1.findViewById(R.id.txt_ngaytra);
                EditText txt_tienthue = view1.findViewById(R.id.txt_tienthue);

                CheckBox chk_trasach = view1.findViewById(R.id.chk_trasach);
                Spinner spn_matv = view1.findViewById(R.id.spn_matv);
                Spinner spn_masach = view1.findViewById(R.id.spn_masach);

                //add data ThanhVien into spinner
                listTV = daoThanhVien.getAllTV();
                ArrayAdapter adapterTV = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, listTV);
                spn_matv.setAdapter(adapterTV);

                listS = daoSach.getAllSach();
                ArrayAdapter adapterS = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, listS);
                spn_masach.setAdapter(adapterS);
                //click view datepicker
                spn_masach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        masach = listS.get(position).getMaSach();
                        tienthue = listS.get(position).getGiaThue();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                txt_ngaytra.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, month);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                txt_ngaytra.setText(dateFormat.format(calendar.getTime()));
                            }
                        };
                        DatePickerDialog pickerDialog = new DatePickerDialog(getContext(), callback, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                        pickerDialog.show();
                    }
                });
                btn_closePM.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                //button save
                btn_insertPM.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (listS.size() <= 0) {
                            Toast.makeText(getContext(), "Chưa có Sách vui lòng thêm Sách trước", Toast.LENGTH_SHORT).show();
                            return;
                        } else if (listTV.size() <= 0) {
                            Toast.makeText(getContext(), "Chưa có Thành Viên vui lòng thêm Thành Viên trước", Toast.LENGTH_SHORT).show();
                            return;
                        } else if (txt_ngaytra.getText().toString().trim().isEmpty()) {
                            Toast.makeText(getContext(), "Không được bỏ trống ngày thuê", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Sach sach = (Sach) spn_masach.getSelectedItem();
                            phieuMuon.setMaSach(sach.getMaSach());
                            ThanhVien thanhVien = (ThanhVien) spn_matv.getSelectedItem();
                            phieuMuon.setMaTV(thanhVien.getMaTV());

                            phieuMuon.setTienThue(tienthue);
                            //
                            phieuMuon.setNgaytra(txt_ngaytra.getText().toString());
                            if (chk_trasach.isChecked()) {
                                phieuMuon.setTraSach(1);
                            } else {
                                phieuMuon.setTraSach(0);
                            }
                            long kq = daoPhieuMuon.insertPM(phieuMuon);
                            if (kq > 0) {
                                listPM.clear();
                                listPM.addAll(daoPhieuMuon.getAllPM());
                                adapterPhieuMuon.notifyDataSetChanged();
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            } else {
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }
                });
            }
        });
        return view;
    }
}
