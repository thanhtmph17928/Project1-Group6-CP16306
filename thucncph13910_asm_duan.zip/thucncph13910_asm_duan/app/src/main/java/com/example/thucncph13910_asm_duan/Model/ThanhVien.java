package com.example.thucncph13910_asm_duan.Model;

public class ThanhVien {
    int maTV;
    String hoTen,namSinh;

    public static final String TABLE_NAME_TV = "thanhvien";
    public static final String TABLE_MATV = "matv";
    public static final String TABLE_HOTEN = "hoten";
    public static final String TABLE_NAMSINH = "namsinh";

    public ThanhVien() {
    }

    public ThanhVien(int maTV, String hoTen, String namSinh) {
        this.maTV = maTV;
        this.hoTen = hoTen;
        this.namSinh = namSinh;
    }

    public int getMaTV() {
        return maTV;
    }

    public void setMaTV(int maTV) {
        this.maTV = maTV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }

    @Override
    public String toString() {
        return this.getMaTV()+"."+this.getHoTen();
    }
}
