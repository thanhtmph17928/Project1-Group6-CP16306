package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterLoaiSach;
import com.example.thucncph13910_asm_duan.Dao.DAOLoaiSach;
import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FragmentLoaiSach extends Fragment {
    FloatingActionButton btn_fLoaiSach;
    RecyclerView recyclerView;
    DAOLoaiSach daoLoaiSach;
    ArrayList<LoaiSach> listLS;
    AdapterLoaiSach adapterLoaiSach;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loaisach, container, false);
        btn_fLoaiSach = view.findViewById(R.id.btn_fLoaiSach);
        recyclerView = view.findViewById(R.id.recycleviewLS);
        daoLoaiSach = new DAOLoaiSach(getContext());
        listLS = new ArrayList<>();
        listLS = daoLoaiSach.getAllLS();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        adapterLoaiSach = new AdapterLoaiSach(getContext(), listLS);
        recyclerView.setAdapter(adapterLoaiSach);


        btn_fLoaiSach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setCancelable(false);
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.dialog_loaisach, null);
                builder.setView(view1);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_huy = view1.findViewById(R.id.btnClose);
                Button btnAddLoaiSach = view1.findViewById(R.id.btnAddLoaiSach);
                EditText txt_TenLoaiSach = view1.findViewById(R.id.txt_TenLoaiSach);
                btnAddLoaiSach.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LoaiSach loaiSach = new LoaiSach();
                        Pattern p = Pattern.compile("^[0-9]+[a-zA-Z0-9]+$");
                        Matcher m = p.matcher(txt_TenLoaiSach.getText().toString());
                        if (m.find()==false){
                            Toast.makeText(getContext(), "Kí tự đầu phải là số", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (txt_TenLoaiSach.getText().toString().trim().isEmpty()){
                            Toast.makeText(getContext(), "Không được bỏ trống tên loại sách", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_TenLoaiSach.getText().toString().length()<5 || txt_TenLoaiSach.getText().toString().length()>20){
                            Toast.makeText(getContext(), "Tiêu đề phải ít nhất 5 kí tự và lớn nhất 20 kí tự", Toast.LENGTH_SHORT).show();
                            return;
                        }


                        else {
                            loaiSach.setHoTen(txt_TenLoaiSach.getText().toString().trim());
                            long kq = daoLoaiSach.insertLoaiSach(loaiSach);
                            if (kq>0){
                                listLS.clear();
                                listLS.addAll(daoLoaiSach.getAllLS());
                                adapterLoaiSach.notifyDataSetChanged();
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }

                    }
                });



                btn_huy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
        return view;
    }
}
