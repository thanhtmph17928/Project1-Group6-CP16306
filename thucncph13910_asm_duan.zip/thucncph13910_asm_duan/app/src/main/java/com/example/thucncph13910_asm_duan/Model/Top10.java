package com.example.thucncph13910_asm_duan.Model;

public class Top10 {
    public String tenSach;
    public int soLuong;

    public Top10() {
    }

    public Top10(String tenSach, int soLuong) {
        this.tenSach = tenSach;
        this.soLuong = soLuong;
    }
}
