package com.example.thucncph13910_asm_duan.Model;

public class Sach {
    int maSach;
    String tenSach;
    int giaThue;
    int sotrang;
    int maLoai;

    public static final String TABLE_NAME_S = "sach";
    public static final String TABLE_MASACH = "masach";
    public static final String TABLE_TENSACH = "tensach";
    public static final String TABLE_GIATHUE = "giathue";
    public static final String TABLE_SOTRANG = "sotrang";

    public static final String TABLE_MALOAI = "maloai";

    public Sach() {
    }

    public Sach(int maSach, String tenSach, int giaThue, int sotrang, int maLoai) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.giaThue = giaThue;
        this.sotrang = sotrang;
        this.maLoai = maLoai;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getGiaThue() {
        return giaThue;
    }

    public void setGiaThue(int giaThue) {
        this.giaThue = giaThue;
    }

    public int getSotrang() {
        return sotrang;
    }

    public void setSotrang(int sotrang) {
        this.sotrang = sotrang;
    }

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

    @Override
    public String toString() {
        return this.getMaSach() + "." + this.getTenSach();
    }
}
