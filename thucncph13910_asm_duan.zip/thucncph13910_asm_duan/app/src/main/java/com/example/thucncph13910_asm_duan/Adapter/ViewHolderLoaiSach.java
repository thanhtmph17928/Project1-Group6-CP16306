package com.example.thucncph13910_asm_duan.Adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.R;

public class ViewHolderLoaiSach extends RecyclerView.ViewHolder {
    TextView tvCustomLoaiSach;
    ImageView img_deleteLS;
    CardView cv_loaisach;

    public ViewHolderLoaiSach(View itemView) {

        super(itemView);
        tvCustomLoaiSach = itemView.findViewById(R.id.tvCustomLoaiSach);
        img_deleteLS = itemView.findViewById(R.id.img_deleteLS);
        cv_loaisach = itemView.findViewById(R.id.cv_loaisach);
    }
}
