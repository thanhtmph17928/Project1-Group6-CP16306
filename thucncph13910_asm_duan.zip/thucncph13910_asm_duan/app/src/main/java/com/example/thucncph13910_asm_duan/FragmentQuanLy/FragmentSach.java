package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.app.SearchManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Adapter.AdapterSach;
import com.example.thucncph13910_asm_duan.Dao.DAOLoaiSach;
import com.example.thucncph13910_asm_duan.Dao.DAOSach;
import com.example.thucncph13910_asm_duan.Model.LoaiSach;
import com.example.thucncph13910_asm_duan.Model.Sach;
import com.example.thucncph13910_asm_duan.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FragmentSach extends Fragment  {
    FloatingActionButton btn_fSach;
    RecyclerView recyclerView;
    DAOSach daoSach;
    ArrayList<Sach> listS;
    ArrayList<LoaiSach> listLS;
    AdapterSach adapterSach;
    DAOLoaiSach daoLoaiSach;
    CardView cv_loaisach;
    EditText txt_search;
    Button btn_search;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sach, container, false);
        btn_fSach = view.findViewById(R.id.btn_fSach);
        recyclerView = view.findViewById(R.id.recycleviewS);
        cv_loaisach = view.findViewById(R.id.cv_loaisach);
        txt_search = view.findViewById(R.id.txt_search);
        btn_search = view.findViewById(R.id.btn_search);
        listS = new ArrayList<>();
        listLS = new ArrayList<>();
        daoLoaiSach = new DAOLoaiSach(getContext());
        daoSach = new DAOSach(getContext());
        listS = daoSach.getAllSach();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        adapterSach = new AdapterSach(getContext(),listS);
        recyclerView.setAdapter(adapterSach);
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String num = txt_search.getText().toString();
                if (txt_search.length()>0){
                    ArrayList<Sach> listnew = daoSach.getSearch(num);
                    adapterSach = new AdapterSach(getContext(),listnew);
                    recyclerView.setAdapter(adapterSach);
                    adapterSach.notifyDataSetChanged();
                }else {
                    adapterSach = new AdapterSach(getContext(),listS);
                    recyclerView.setAdapter(adapterSach);
                }
            }
        });
        btn_fSach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.dialog_addsach,null);
                builder.setView(view1);
                builder.setCancelable(false);
                AlertDialog alertDialog = builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_closeS = view1.findViewById(R.id.btn_closeS);
                Button btn_insertS = view1.findViewById(R.id.btn_insertS);
                EditText txt_tenS = view1.findViewById(R.id.txt_tenS);
                EditText txt_giathueS = view1.findViewById(R.id.txt_giathueS);
                EditText txt_sotrangS = view1.findViewById(R.id.txt_sotrangS);
                Spinner spn_maloai = view1.findViewById(R.id.spn_maloai);
                listLS = daoLoaiSach.getAllLS();
                ArrayAdapter adapter = new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1,listLS);
                spn_maloai.setAdapter(adapter);
                btn_insertS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (listLS.size()<=0){
                            Toast.makeText(getContext(), "Chưa có Loại Sách , vui lòng thêm loại sách trước", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (txt_tenS.getText().toString().trim().isEmpty()){
                            Toast.makeText(getContext(), "Không được bỏ trống tên sách", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (txt_giathueS.getText().toString().trim().isEmpty()){
                            Toast.makeText(getContext(), "Không được bỏ trống giá thuê", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            Sach sach = new Sach();
                            sach.setTenSach(txt_tenS.getText().toString());
                            sach.setGiaThue(Integer.parseInt(txt_giathueS.getText().toString()));
                            sach.setSotrang(Integer.parseInt(txt_sotrangS.getText().toString()));
                            LoaiSach loaiSach = (LoaiSach)spn_maloai.getSelectedItem();
                            sach.setMaLoai(loaiSach.getMaLoai());
                            long kq = daoSach.insertSach(sach);
                            if (kq>0){
                                listS.clear();
                                listS.addAll(daoSach.getAllSach());
                                adapterSach.notifyDataSetChanged();
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }else {
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        }
                    }
                });


                btn_closeS.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
        return view;
    }
}
