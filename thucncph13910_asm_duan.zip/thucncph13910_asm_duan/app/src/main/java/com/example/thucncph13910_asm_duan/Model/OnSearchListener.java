package com.example.thucncph13910_asm_duan.Model;

public interface OnSearchListener {
    void onSearch(String str);
}
