package com.example.thucncph13910_asm_duan.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.Dao.DAOThuThu;
import com.example.thucncph13910_asm_duan.Model.ThuThu;
import com.example.thucncph13910_asm_duan.R;

import java.util.ArrayList;

public class AdapterThemUser extends RecyclerView.Adapter<AdapterThemUser.ViewHolderThemUser> {
    Context context;
    ArrayList<ThuThu> listTT;
    ArrayList<ThuThu> listTTOld;
    DAOThuThu daoThuThu;

    public AdapterThemUser(Context context, ArrayList<ThuThu> listTT) {
        this.context = context;
        this.listTT = listTT;
        this.listTTOld = listTT;
        daoThuThu = new DAOThuThu(context);
    }

    @Override
    public ViewHolderThemUser onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_themuser,null);
        return new ViewHolderThemUser(view);
    }
    @Override
    public void onBindViewHolder(ViewHolderThemUser holder, int position) {
            ThuThu thuThu = listTT.get(position);
            holder.tvName.setText("Họ và tên: " +thuThu.getHoTen());
            holder.tvUser.setText("User: "+  thuThu.getMaTT());
            holder.tvPass.setText("Password: " + thuThu.getMaKhau());
    }

    @Override
    public int getItemCount() {
        return listTT.size();
    }
    public class ViewHolderThemUser extends RecyclerView.ViewHolder {
        TextView tvName,tvUser,tvPass;
        public ViewHolderThemUser(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvUser = itemView.findViewById(R.id.tvUser);
            tvPass = itemView.findViewById(R.id.tvPass);
        }
    }

}
