package com.example.thucncph13910_asm_duan.FragmentQuanLy;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.thucncph13910_asm_duan.Dao.DAOThongKe;
import com.example.thucncph13910_asm_duan.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FragmentDoanhThu extends Fragment {
    Button btn_tungay,btn_denngay,btn_doanhthu;
    EditText txt_tungay,txt_denngay;
    TextView tvdoanhthu;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Calendar calendar = Calendar.getInstance();
    DAOThongKe daoThongKe;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doanhthu,container,false);
        btn_tungay = view.findViewById(R.id.btn_tungay);
        btn_denngay = view.findViewById(R.id.btn_denngay);
        btn_doanhthu = view.findViewById(R.id.btn_doanhthu);
        txt_tungay = view.findViewById(R.id.txt_tungay);
        txt_denngay = view.findViewById(R.id.txt_denngay);
        tvdoanhthu = view.findViewById(R.id.tvdoanhthu);
        daoThongKe = new DAOThongKe(getContext());
        btn_tungay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        txt_tungay.setText(dateFormat.format(calendar.getTime()));
                    }
                };
                DatePickerDialog pickerDialog = new DatePickerDialog(getContext(), callback, calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                pickerDialog.show();
            }
        });
        btn_denngay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        txt_denngay.setText(dateFormat.format(calendar.getTime()));
                    }
                };
                DatePickerDialog pickerDialog = new DatePickerDialog(getContext(), callback, calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                pickerDialog.show();
            }
        });
        btn_doanhthu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tungay = txt_tungay.getText().toString();
                String denngay = txt_denngay.getText().toString();
                tvdoanhthu.setText("Doanh thu: " + daoThongKe.getDoanhThu(tungay,denngay)+"đ");
            }
        });
        return view;
    }
}
