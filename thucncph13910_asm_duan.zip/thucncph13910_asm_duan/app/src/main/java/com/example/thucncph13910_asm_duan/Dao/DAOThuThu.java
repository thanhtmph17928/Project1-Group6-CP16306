package com.example.thucncph13910_asm_duan.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thucncph13910_asm_duan.Database.CreateDatabase;
import com.example.thucncph13910_asm_duan.Model.ThuThu;

import java.util.ArrayList;

public class DAOThuThu {
    CreateDatabase createDatabase;

    public DAOThuThu(Context context) {
        createDatabase = new CreateDatabase(context);
    }
    public  long insertTT(ThuThu thuThu){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ThuThu.TABLE_MATT,thuThu.getMaTT());
        values.put(ThuThu.TABLE_HOTEN,thuThu.getHoTen());
        values.put(ThuThu.TABLE_MATKHAU,thuThu.getMaKhau());
        long kq = database.insert(ThuThu.TABLE_NAME_TT,null,values);
        return kq;
    }
    public  int updateTT(ThuThu thuThu){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ThuThu.TABLE_MATKHAU,thuThu.getMaKhau());
        int kq = database.update(ThuThu.TABLE_NAME_TT,values,"matt =? ",new String[]{thuThu.getMaTT()});
        return kq;
    }
    public int deleteTT(String ma){
        SQLiteDatabase database = createDatabase.getWritableDatabase();
        return database.delete(ThuThu.TABLE_NAME_TT,"matt =? ",new String[]{ma});
    }
    public ArrayList<ThuThu> getAllDK(String sql,String... a){
        SQLiteDatabase database = createDatabase.getReadableDatabase();
        ArrayList<ThuThu> listTT = new ArrayList<>();
        Cursor cursor= database.rawQuery(sql,a);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            String matt = cursor.getString(0);
            String hoten = cursor.getString(1);
            String pass = cursor.getString(2);
            ThuThu thuThu = new ThuThu(matt,hoten,pass);
            listTT.add(thuThu);
            cursor.moveToNext();
        }
        cursor.close();
        database.close();
        return listTT;
    }
    public ArrayList<ThuThu> getAllTT(){
        String sele = "SELECT * FROM " + ThuThu.TABLE_NAME_TT;
        return getAllDK(sele);
    }
    public ThuThu getID(String id){
        String sql =  "SELECT * FROM thuthu WHERE matt=? ";
        ArrayList<ThuThu> listTT = getAllDK(sql,id);
        return listTT.get(0);
    }

    public int checkLogin(String id,String pass){
        String sql = "SELECT * FROM thuthu WHERE matt =? AND matkhau =? ";
        ArrayList<ThuThu> list = getAllDK(sql,id,pass);
        if (list.size()==0)
            return -1;
        return 1;
    }
}
