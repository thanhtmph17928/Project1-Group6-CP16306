package com.example.thucncph13910_asm_duan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentDoanhThu;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentDoiPass;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentLoaiSach;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentPhieuMuon;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentSach;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentThanhVien;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentThemUser;
import com.example.thucncph13910_asm_duan.FragmentQuanLy.FragmentTop10;
import com.example.thucncph13910_asm_duan.Model.OnSearchListener;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    NavigationView nav_view;
    DrawerLayout drawerLayout;
    FragmentManager fragmentManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControl();
        addEvent();

    }

    private void addEvent() {
        FragmentPhieuMuon phieuMuon = new FragmentPhieuMuon();
        fragmentManager.beginTransaction().add(R.id.fragment_view,phieuMuon).commit();
        nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_qlphieumuon:
                        setTitle("Phiếu Mượn");
                        FragmentPhieuMuon phieuMuon = new FragmentPhieuMuon();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,phieuMuon).commit();
                        break;
                    case R.id.ic_qlloaisach:
                        setTitle("Loại Sách");
                        FragmentLoaiSach loaiSach = new FragmentLoaiSach();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,loaiSach).commit();
                        break;
                    case R.id.ic_qlsach:
                        setTitle("Sách");
                        FragmentSach sach = new FragmentSach();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,sach).commit();
                        break;
                    case R.id.ic_qlthanhvien:
                        setTitle("Thành Viên");
                        FragmentThanhVien thanhVien = new FragmentThanhVien();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,thanhVien).commit();
                        break;
                    case R.id.ic_top10:
                        setTitle("Top 10 Sách Bán Chạy");
                        FragmentTop10 top10 = new FragmentTop10();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,top10).commit();
                        break;
                    case R.id.ic_doanhthu:
                        setTitle("Doanh Thu");
                        FragmentDoanhThu doanhThu = new FragmentDoanhThu();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,doanhThu).commit();
                        break;
                    case R.id.ic_themnguoidung:
                        setTitle("Thêm Người Dùng");
                        FragmentThemUser themUser = new FragmentThemUser();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,themUser).commit();
                        break;
                    case R.id.ic_doipass:
                        setTitle("Đổi Mật Khẩu");
                        FragmentDoiPass doiPass = new FragmentDoiPass();
                        fragmentManager.beginTransaction().replace(R.id.fragment_view,doiPass).commit();
                        break;
                    case R.id.ic_out:
                        startActivity(new Intent(MainActivity.this,LoginActivity.class));
                }

                drawerLayout.closeDrawer(nav_view);
                return false;
            }
        });
        Intent intent = getIntent();
        String userr = intent.getStringExtra("user");
        if (userr.equalsIgnoreCase("admin")){
            nav_view.getMenu().findItem(R.id.ic_themnguoidung).setVisible(true);
        }else {
            nav_view.getMenu().findItem(R.id.ic_themnguoidung).setVisible(false);
        }
    }

    private void addControl() {
        toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.icmenu);

        nav_view = findViewById(R.id.nav_view);
        drawerLayout = findViewById(R.id.drawer_layout);
        fragmentManager = getSupportFragmentManager();
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawerLayout =findViewById(R.id.drawer_layout);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }

    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()== android.R.id.home){
            drawerLayout.openDrawer(nav_view);
        }
        return super.onOptionsItemSelected(item);
    }

}