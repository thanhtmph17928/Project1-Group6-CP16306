package com.example.thucncph13910_asm_duan.Adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.thucncph13910_asm_duan.R;

public class ViewHolderTop10 extends RecyclerView.ViewHolder {
    TextView tvtensachTop10,tvsoluongTop10;
    public ViewHolderTop10(View itemView) {
        super(itemView);
        tvtensachTop10 = itemView.findViewById(R.id.tvtensachTop10);
        tvsoluongTop10 = itemView.findViewById(R.id.tvsoluongTop10);
    }
}
